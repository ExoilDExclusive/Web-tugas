(function() {
  const body = document.body;
  const logoPng = body.dataset.logoPng || 'assets/logo.png';
  const logoVideo = body.dataset.logoVideo || 'assets/logo.mp4';
  const slides = [body.dataset.slide1, body.dataset.slide2, body.dataset.slide3];
  
  const logoImg = document.getElementById('logoImg');
  const logoVideoEl = document.getElementById('logoVideo');
  const logoWrap = document.getElementById('logoWrap');
  let showingVideo = false;
  
  function loadLogoAssets() {
    logoImg.src = logoPng;
    logoImg.style.display = 'block';
    logoVideoEl.src = logoVideo;
    logoVideoEl.load();
    logoVideoEl.style.display = 'none';
  }
  
  function toggleLogo() {
    if (showingVideo) {
      logoVideoEl.pause();
      logoVideoEl.style.display = 'none';
      logoImg.style.display = 'block';
      showingVideo = false;
    } else {
      logoImg.style.display = 'none';
      logoVideoEl.style.display = 'block';
      logoVideoEl.play().catch(() => {});
      showingVideo = true;
    }
  }
  
  logoWrap.addEventListener('click', toggleLogo);
  setInterval(toggleLogo, 7000);
  
  const kompetensiToggle = document.getElementById('kompetensiToggle');
  const kompetensiMenu = document.getElementById('kompetensiMenu');
  
  kompetensiToggle.addEventListener('click', () => {
    const open = kompetensiMenu.style.display === 'flex';
    kompetensiMenu.style.display = open ? 'none' : 'flex';
  });
  
  document.addEventListener('click', (e) => {
    if (!kompetensiToggle.contains(e.target) && !kompetensiMenu.contains(e.target)) {
      kompetensiMenu.style.display = 'none';
    }
  });
  
  document.querySelectorAll('.navlinks a, .dropdown-menu a').forEach(a => {
    a.addEventListener('click', (e) => {
      e.preventDefault();
      const target = a.dataset.link || a.getAttribute('href');
      if (target.startsWith('#')) {
        const el = document.querySelector(target);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      } else {
        window.location.href = target;
      }
    });
  });
  
  const carousel = document.getElementById('carousel');
  const slideEls = Array.from(carousel.querySelectorAll('.slide'));
  const dotsWrap = document.getElementById('dots');
  let current = 0;
  
  function setupSlides() {
    slideEls.forEach((s, i) => {
      const img = s.querySelector('img');
      img.src = slides[i] || '';
    });
    
    dotsWrap.innerHTML = '';
    slideEls.forEach((s, i) => {
      const d = document.createElement('div');
      d.className = 'dot';
      d.dataset.index = i;
      d.addEventListener('click', () => showSlide(i));
      dotsWrap.appendChild(d);
    });
    
    showSlide(0);
  }
  
  function showSlide(i) {
    slideEls.forEach(s => s.classList.remove('active'));
    slideEls[i].classList.add('active');
    
    dotsWrap.querySelectorAll('.dot').forEach(d => d.classList.remove('active'));
    const dot = dotsWrap.querySelector(`.dot[data-index='${i}']`);
    if (dot) dot.classList.add('active');
    
    current = i;
  }
  
  document.getElementById('prevBtn').addEventListener('click', () => {
    showSlide((current - 1 + slideEls.length) % slideEls.length);
  });
  
  document.getElementById('nextBtn').addEventListener('click', () => {
    showSlide((current + 1) % slideEls.length);
  });
  
  let slideAuto = setInterval(() => {
    showSlide((current + 1) % slideEls.length);
  }, 6000);
  
  carousel.addEventListener('mouseenter', () => clearInterval(slideAuto));
  carousel.addEventListener('mouseleave', () => {
    slideAuto = setInterval(() => {
      showSlide((current + 1) % slideEls.length);
    }, 6000);
  });
  
  function renderVideos(list) {
    const wrap = document.getElementById('videoList');
    wrap.innerHTML = '';
    
    if (!list || !list.length) {
      wrap.innerHTML = '<p style="color:var(--muted)">Tidak ada video. Tambahkan file assets/videos.js</p>';
      return;
    }
    
    list.forEach(v => {
      const card = document.createElement('div');
      card.className = 'video-card';
      
      const thumb = document.createElement('div');
      thumb.className = 'video-thumb';
      
      const iframe = document.createElement('iframe');
      iframe.src = 'https://www.youtube.com/embed/' + encodeURIComponent(v.ytId);
      iframe.setAttribute('allowfullscreen', '');
      
      thumb.appendChild(iframe);
      
      const meta = document.createElement('div');
      meta.className = 'video-meta';
      
      const h3 = document.createElement('h3');
      h3.textContent = v.title || 'Video';
      
      const p = document.createElement('p');
      p.textContent = 'Link YouTube: https://youtu.be/' + v.ytId;
      
      meta.appendChild(h3);
      meta.appendChild(p);
      
      card.appendChild(thumb);
      card.appendChild(meta);
      
      wrap.appendChild(card);
    });
  }
  
  function loadVideosConfig() {
    return new Promise((resolve) => {
      const s = document.createElement('script');
      s.src = 'assets/videos.js';
      s.onload = () => resolve(window.VIDEOS || []);
      s.onerror = () => resolve([]);
      document.head.appendChild(s);
    });
  }
  
  loadLogoAssets();
  setupSlides();
  
  loadVideosConfig().then(list => renderVideos(list));
})();